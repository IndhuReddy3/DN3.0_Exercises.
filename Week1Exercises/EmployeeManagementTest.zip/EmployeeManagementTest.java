package com.employee.manage;

public class Test {
    public static void main(String[] args) {
        // Create the Employee Management System with capacity of 5
        EmployeeManagementSystem system = new EmployeeManagementSystem(5);

        // Create and add employees
        system.addEmployee(new Employee(1, "Alice", "Manager", 70000));
        system.addEmployee(new Employee(2, "Bob", "Developer", 60000));
        system.addEmployee(new Employee(3, "Charlie", "Analyst", 50000));

        // Traverse and print all employees
        System.out.println("All Employees:");
        system.traverseEmployees();

        // Search for an employee
        System.out.println("\nSearching for employee with ID 2:");
        Employee emp = system.searchEmployee(2);
        System.out.println(emp);

        // Delete an employee
        System.out.println("\nDeleting employee with ID 2:");
        system.deleteEmployee(2);

        // Traverse and print all employees after deletion
        System.out.println("\nAll Employees after deletion:");
        system.traverseEmployees();
    }
}