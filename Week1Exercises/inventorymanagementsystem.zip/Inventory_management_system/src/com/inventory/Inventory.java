package com.inventory;

import java.util.HashMap;

public class Inventory {
    private HashMap<String, Product> inventory;

    public Inventory() {
        this.inventory = new HashMap<>();
    }

    // Method to add a product
    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }

    // Method to update a product
    public void updateProduct(String productId, Product updatedProduct) {
        if (inventory.containsKey(productId)) {
            inventory.put(productId, updatedProduct);
        } else {
            System.out.println("Product not found");
        }
    }

    // Method to delete a product
    public void deleteProduct(String productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
        } else {
            System.out.println("Product not found");
        }
    }

    // Method to get a product
    public Product getProduct(String productId) {
        return inventory.get(productId);
    }

    // Main method for testing
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        // Adding products
        Product product1 = new Product("P001", "Product 1", 100, 10.99);
        Product product2 = new Product("P002", "Product 2", 200, 15.99);

        inventory.addProduct(product1);
        inventory.addProduct(product2);

        // Displaying a product
        System.out.println("Product ID: " + inventory.getProduct("P001").getProductId());
        System.out.println("Product Name: " + inventory.getProduct("P001").getProductName());

        // Updating a product
        Product updatedProduct1 = new Product("P001", "Updated Product 1", 150, 12.99);
        inventory.updateProduct("P001", updatedProduct1);

        // Displaying the updated product
        System.out.println("Updated Product Name: " + inventory.getProduct("P001").getProductName());

        // Deleting a product
        inventory.deleteProduct("P002");

        // Trying to display the deleted product
        Product deletedProduct = inventory.getProduct("P002");
        if (deletedProduct == null) {
            System.out.println("Product P002 not found");
        }
    }
}


