package com.ecommerce;

public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product("P001", "Product 1", "Category 1"),
            new Product("P002", "Product 2", "Category 1"),
            new Product("P003", "Product 3", "Category 2"),
            new Product("P004", "Product 4", "Category 2"),
            new Product("P005", "Product 5", "Category 3")
        };

        // Linear search test
        Product foundProduct = Search.linearSearch(products, "P003");
        if (foundProduct != null) {
            System.out.println("Linear Search: Found " + foundProduct.getProductName());
        } else {
            System.out.println("Linear Search: Product not found");
        }

        // Binary search test
        foundProduct = Search.binarySearch(products, "P003");
        if (foundProduct != null) {
            System.out.println("Binary Search: Found " + foundProduct.getProductName());
        } else {
            System.out.println("Binary Search: Product not found");
        }
    }
}