package com.financial;

public class FinancialForecasting {

    // Recursive method to calculate future value
    public static double futureValueRecursive(double principal, double rate, int years) {
        // Base case
        if (years == 0) {
            return principal;
        }
        // Recursive case
        return futureValueRecursive(principal, rate, years - 1) * (1 + rate);
    }

    public static void main(String[] args) {
        double principal = 1000; // Initial investment
        double rate = 0.05; // Annual growth rate
        int years = 10; // Number of years

        double futureValue = futureValueRecursive(principal, rate, years);
        System.out.println("Future Value (Recursive): " + futureValue);
    }
}