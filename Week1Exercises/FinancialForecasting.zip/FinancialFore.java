package com.financial;

public class FinancialFore{

    // Iterative method to calculate future value
    public static double futureValueIterative(double principal, double rate, int years) {
        double value = principal;
        for (int i = 0; i < years; i++) {
            value *= (1 + rate);
        }
        return value;
    }

    public static void main(String[] args) {
        double principal = 1000; // Initial investment
        double rate = 0.05; // Annual growth rate
        int years = 10; // Number of years

        double futureValue = futureValueIterative(principal, rate, years);
        System.out.println("Future Value (Iterative): " + futureValue);
    }
}