package com.task.management;

public class Test {
    public static void main(String[] args) {
        // Create the Task Management System
        TaskManagementSystem system = new TaskManagementSystem();

        // Create and add tasks
        system.addTask(new Task(1, "Task One", "Pending"));
        system.addTask(new Task(2, "Task Two", "In Progress"));
        system.addTask(new Task(3, "Task Three", "Completed"));

        // Traverse and print all tasks
        System.out.println("All Tasks:");
        system.traverseTasks();

        // Search for a task
        System.out.println("\nSearching for task with ID 2:");
        Task task = system.searchTask(2);
        System.out.println(task);

        // Delete a task
        System.out.println("\nDeleting task with ID 2:");
        system.deleteTask(2);

        // Traverse and print all tasks after deletion
        System.out.println("\nAll Tasks after deletion:");
        system.traverseTasks();
    }
}
