package com.library.manage;

public class Test {
    public static void main(String[] args) {
        // Create the Library Management System
        LibraryManagementSystem library = new LibraryManagementSystem();

        // Add books to the library
        library.addBook(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"));
        library.addBook(new Book(2, "1984", "George Orwell"));
        library.addBook(new Book(3, "To Kill a Mockingbird", "Harper Lee"));

        // Test Linear Search
        System.out.println("Searching for '1984' using Linear Search:");
        Book book = library.searchBookByTitleLinear("1984");
        System.out.println(book);

        // Sort books for Binary Search
        library.sortBooks();

        // Test Binary Search
        System.out.println("\nSearching for 'To Kill a Mockingbird' using Binary Search:");
        book = library.searchBookByTitleBinary("To Kill a Mockingbird");
        System.out.println(book);
    }
}